package com.gotwiki.gotwiki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GotWikiApplication {

    public static void main(String[] args) {
        SpringApplication.run(GotWikiApplication.class, args);
    }

}
