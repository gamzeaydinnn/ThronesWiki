package com.gotwiki.gotwiki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GotWikiApplicationTests {

    @Test
    void contextLoads() {
    }

}
